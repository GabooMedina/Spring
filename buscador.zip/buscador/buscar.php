<?php


function buscar($nombre){

    include("conexion.php");

    $sql = "SELECT* FROM bodegas WHERE id_bod =(SELECT id_bod_per FROM productos WHERE nom_pro ='$nombre')";

    $respuesta = $con->query($sql);
    $resultado = array();
    if ($respuesta->num_rows > 0) {

        while ($fila = $respuesta->fetch_assoc()) {
            $resultado[] = $fila;
        }
    } else {
        echo ("No se encontraron Resultados");
    }

    return $resultado;
}

?>