<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form action="" method="post">

    INGRESE EL NOMBRE DEL PRODUCTO:
    <input type="text" id="nombre" name="nombre"> <br>
    <input type="submit" value="BUSCAR"> 

    </form>

    <?php
    include("buscar.php");

    if(isset($_POST["nombre"])) {
        
        $resultados = buscar($_POST["nombre"]);
        
        // Mostrar los resultados en una tabla si existen
        if(!empty($resultados)) {
            echo "<h2>Resultados</h2><br>";
            echo "<table border='1'>";
            echo "<tr><th>ID</th><th>Nombre</th><th>Telefono</th><th>Direccion</th></tr>";
            
            foreach($resultados as $fila) {
                echo "<tr>";
                echo "<td>".$fila['id_bod']."</td>";
                echo "<td>".$fila['nom_bod']."</td>";
                echo "<td>".$fila['tel_bod']."</td>";
                echo "<td>".$fila['dir_bod']."</td>";
                // Añade aquí más columnas según tu estructura de base de datos
                echo "</tr>";
            }
            
            echo "</table>";
        } else {
            echo "No se encontraron resultados para el nombre '".$_POST['nombre']."'.";
        }
    }
    ?>

</body>
</html>


