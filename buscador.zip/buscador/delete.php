<?php
include("conexion.php");

$id=$_POST["id"];

$sql="DELETE FROM productos WHERE id_pro= '$id' ";
$sql2="DELETE FROM bodegas WHERE id_bod= (SELECT id_bod_per FROM productos WHERE id_pro='$id')";
if (mysqli_query($con,$sql)) {
    echo json_encode("se borro");
} else {
    echo json_encode("no borro");
}

?>