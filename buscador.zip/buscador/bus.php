<?php
include("conexion.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form method="get" action="">

        INGRESE EL NOMBRE DEL PRODUCTO
        <input type="text" id="buscar" name="buscar"> <br>
        <input type="submit" value="enviar" name="enviar">

    </form>

    <?php
    if (isset($_GET["enviar"])) {
        $buscar = $_GET["buscar"];
        $SQL = $con->query("SELECT * FROM bodegas WHERE id_bod =(SELECT id_bod_per FROM productos WHERE nom_pro ='$buscar')");
        while ($row = $SQL->fetch_array()) {
            echo "<table border='1'>";
            echo "<tr><th>ID</th><th>Nombre</th><th>Teléfono</th><th>Dirección</th></tr>"; // Nombres de las columnas
            echo "<td>" . $row["id_bod"] . "</td>";
            echo "<td>" . $row["nom_bod"] . "</td>";
            echo "<td>" . $row["tel_bod"] . "</td>";
            echo "<td>" . $row["dir_bod"] . "</td>";
            echo "</tr>";

            echo "</table>";
        }
    }

    ?>

</body>

</html>