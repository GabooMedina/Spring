<?php

include("conexion.php");

$id=$_POST["id"];
$nombre=$_POST["nombre"];
$precio=$_POST["precio"];
$bodega=$_POST["bodega"];

$sql = "INSERT INTO productos (id_pro,nom_pro,pre_pro,id_bod_per) VALUES ('$id','$nombre','$precio','$bodega')";

if (mysqli_query($con,$sql)) {
    echo json_encode("SE REGISTRO");
} else {
    echo json_encode("NO REGISTRO");

}

?>