<?php

$servername="localhost";
$user="root";
$psw="";
$db="mercado";

$con=mysqli_connect($servername,$user,$psw,$db);


if ($con) {
} else {
    
}



?>