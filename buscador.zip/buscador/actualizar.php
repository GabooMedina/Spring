<?php
include("conexion.php");

$id=$_POST["id"];
$nombre=$_POST["nombre"];
$precio=$_POST["precio"];
$bodega=$_POST["bodega"];

$sql="UPDATE productos SET  nom_pro='$nombre', pre_pro='$precio', id_bod_per='$bodega' WHERE id_pro='$id'";

if ($con -> query($sql) == true){
    echo json_encode("Usuario actualizado");
}else{
    echo json_encode("Actualización errónea");
}


?>